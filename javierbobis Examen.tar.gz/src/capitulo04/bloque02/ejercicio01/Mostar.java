package capitulo04.bloque02.ejercicio01;

public class Mostar {
	public static void main(String[] args) {
		Lista persona1 = new Lista();
		
		System.out.println(persona1);
	}
	
}
