package capitulo04.bloque03;

public class Malvado extends Personaje {

	public Malvado() {
		super();
	}

	public Malvado(int vida, String nombre, boolean vivo, int disparosrecibidos) {
		super(vida, nombre, vivo, disparosrecibidos);
		// TODO Auto-generated constructor stub
	}
	
}
