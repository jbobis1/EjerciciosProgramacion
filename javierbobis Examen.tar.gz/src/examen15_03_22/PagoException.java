package examen15_03_22;

public class PagoException extends Exception {

	public PagoException() {
		// TODO Auto-generated constructor stub
	}

	public PagoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PagoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PagoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PagoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
