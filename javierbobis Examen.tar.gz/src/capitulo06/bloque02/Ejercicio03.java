package capitulo06.bloque02;

public class Ejercicio03 {

	public static void main(String[] args) {
		System.out.println("Hipotenusa de un trianngulo rectangulo, "
				+ "dados dos de los catetos del mismo: " + Math.hypot(4, 5));
	}

	
	
}
