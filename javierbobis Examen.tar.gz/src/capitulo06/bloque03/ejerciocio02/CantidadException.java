package capitulo06.bloque03.ejerciocio02;

public class CantidadException extends Exception {


	public CantidadException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
