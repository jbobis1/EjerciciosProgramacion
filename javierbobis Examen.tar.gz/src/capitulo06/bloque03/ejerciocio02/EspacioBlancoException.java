package capitulo06.bloque03.ejerciocio02;

public class EspacioBlancoException extends Exception {
	
	
	public EspacioBlancoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
