package capitulo06.bloque03.ejerciocio02;

public class NoBombillaException extends Exception {

	public NoBombillaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
