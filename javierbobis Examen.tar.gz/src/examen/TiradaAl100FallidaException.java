package examen;

public class TiradaAl100FallidaException extends Exception {

	public TiradaAl100FallidaException() {
		// TODO Auto-generated constructor stub
	}

	public TiradaAl100FallidaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TiradaAl100FallidaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TiradaAl100FallidaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TiradaAl100FallidaException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
