package ejercicio.ejercicio03;

import javax.swing.JOptionPane;

public class Ejercico03 {

		public static void main(String[] args) {
		String cadena = "hola";
		String cadena1 = "";
		
			//	JOptionPane.showInputDialog("Primer Numero:  ");
	
		
		//	String cadena ="hollaaa";
			
			System.out.println(numero(cadena,cadena1));
		}
		public static String numero(String cadena,String cadena1) {

			
			for(int i =0; i < cadena(i); i++) {
				
				if(cadena(i)=='a') {
					cadena1= cadena="e";
					
				}
				else if(cadena(i)!='a') {
					cadena1 = cadena;
						
				}
			} 	
		//System.out.println("la nueva cadena es " + cadena1 );
			return cadena1;
		}
		private static int cadena(int i) {
			// TODO Auto-generated method stub
			return 0;
		}
		
}
