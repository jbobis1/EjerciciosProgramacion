package capitulo05.bloque04opcional;

public class Ejercicio02 {

}
