package capitulo04.bloque03;

public class Humano extends Personaje {

	public Humano() {
		super();
	}


	public Humano(int vida, String nombre, boolean vivo, int disparosrecibidos) {
		super(vida, nombre, vivo, disparosrecibidos);
		// TODO Auto-generated constructor stub
	}
	
}
