package capitulo04.bloque00.array;

public class ArraydeNumero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array miprimerArray = new array();
		miprimerArray.mostrar();
		miprimerArray.media();
	

	}

}
