package capitulo04.bloque00;

public class Gertionarcromosbaloncesto {

	public static void main(String[] args) {
		GesionarCromo cromo1= new GesionarCromo("curry", 192 , 92 , 35);
		GesionarCromo cromo2= new GesionarCromo("lebrom", 206 , 110 , 26);
		System.out.println(cromo1.toString() + "\n" + cromo2.toString());

	
	}
	
	
}
