package capitulo04.bloque02.ejercicio02;

public class Mostar {
	public static void main(String[] args) {
		Texto persona1 = new Texto();
		
		System.out.println(persona1);
	}
	
}


