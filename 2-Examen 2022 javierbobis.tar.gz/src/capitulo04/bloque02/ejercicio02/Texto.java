package capitulo04.bloque02.ejercicio02;

public class Texto {

		 private String texto;
		 
			public Texto() {
				super();
				// TODO Auto-generated constructor stub
			}
			
		@Override
		public String toString() {
			return "Texto [texto=" + texto + "]";
		}

		public String getTexto() {
			return texto;
		}

		public void setTexto(String texto) {
			this.texto = texto;
		}


}
