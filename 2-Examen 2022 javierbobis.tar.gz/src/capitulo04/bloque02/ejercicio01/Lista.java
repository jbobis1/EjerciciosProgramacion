package capitulo04.bloque02.ejercicio01;

public class Lista {
	public Lista() {
		super();
		// TODO Auto-generated constructor stub
	}

	private String numero	;

	@Override
	public String toString() {
		return "Lista [numero=" + numero + "]";
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}


	
}
