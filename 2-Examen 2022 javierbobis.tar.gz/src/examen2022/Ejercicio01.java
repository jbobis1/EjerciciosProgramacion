package examen2022;

import java.util.HashMap;

public class Ejercicio01 {

	public static void main(String[] args) {

		int Pi=(3+4/(2**4)-4/(4*5*6)+4());
		
		
		for (int i = 0; i < Pi.length; i++) {
		
			
			System.out.println(Pi);
			
	}

		
	}
}
