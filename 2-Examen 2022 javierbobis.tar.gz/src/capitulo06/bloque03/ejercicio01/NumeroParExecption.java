package capitulo06.bloque03.ejercicio01;

public class NumeroParExecption extends Exception {

	public NumeroParExecption(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
