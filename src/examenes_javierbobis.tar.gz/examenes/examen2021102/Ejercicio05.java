package examenes.examen2021102;

import javax.swing.JOptionPane;

public class Ejercicio05 {
	public static void main(String[] args) {
		
		//Declaramos las variables
		int numeros;
		int suma =0;
		int mult=0;
		
		//Cremos el buble que se repetiras 10 veces y tambien que el numero sea aleatorio
		for (int i = 0; numero ==numero; i++) {
			//creacion del numero aleatorio
			numero = (int)Math.round(Math.random() * (150 - 0)) + 0;
			int numeros = Integer.parseInt(JOptionPane.showInputDialog("numeroque quires: "));

			System.out.println(numero);
			
			//
			  if ((numero ==numeros) != 0) {
					
				  System.out.println("fin"); 
			  
		} 
	
	}	

}
